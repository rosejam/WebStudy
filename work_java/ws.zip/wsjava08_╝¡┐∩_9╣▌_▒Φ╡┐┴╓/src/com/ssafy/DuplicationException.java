/*package com.ssafy;

import java.util.Arrays;

public class DuplicationException extends Exception {

	@Override
	public String toString() {
		return "DuplicationException [getMessage()=" + getMessage() + ", getLocalizedMessage()=" + getLocalizedMessage()
				+ ", getCause()=" + getCause() + ", toString()=" + super.toString() + ", fillInStackTrace()="
				+ fillInStackTrace() + ", getStackTrace()=" + Arrays.toString(getStackTrace())
				+ ", getStackTraceDepth()=" + getStackTraceDepth() + ", getSuppressed()="
				+ Arrays.toString(getSuppressed()) + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
	
}
*/