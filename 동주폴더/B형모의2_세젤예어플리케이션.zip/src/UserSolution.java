class UserSolution 
{
	
    private char Table[][][];
    
    void initTable()
    {
        // TO DO
    }
    
    boolean updateCell(int row, int col, char equation[], int value[][])
    {
        // TO DO
		
				return true; // Need to be changed
    }    
}
