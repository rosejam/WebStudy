package com.book;

public class ISBNNotFoundException extends Exception{
	@Override
	public String toString() {		
		return "ISBNNotFoundException �߻�:���� ISBN�Դϴ�";
		
	}
}
