package com.basic;


public class Test6 {

	public static void main(String[] args) {
		Test6 t = new Test6();
		System.out.println(t + "gogo");		
	}

	@Override
	public String toString() {
		return "harry";
	}

}
