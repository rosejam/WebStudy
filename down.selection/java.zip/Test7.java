package com.basic;

class ParentClass{
	void go() {
		System.out.println("one");
	}
}

class ChildClass {

	public static void main(String[] args) {
	
		
		
	}

}
