package com.basic;

/*class Super{}
class Earth extends Super{}
class Moon extends Earth{}
class Star extends Super{}
class Sun{}

public class Test3 {	
	public static void main(String[] args) {
		Super s = new Earth();
		Super s2 = new Moon();
		Sun s3 = new Star();
		Earth s4 = new Moon();

	}

}*/
