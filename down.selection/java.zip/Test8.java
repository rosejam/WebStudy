package com.basic;


public class Test8 {	

	public static void main(String[] args) {
		/*int num;
		System.out.println(num);*/
		
	}

}
