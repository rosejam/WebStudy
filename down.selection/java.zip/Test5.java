package com.basic;

public class Test5 {

	public static void main(String[] args) {
	//	char s = '';
	/*	byte a = 128; -128~127
		double s = 9;
		boolean g = 1;
		char c = '';
		float d = 3.4f;
		
		String q = "";*/
		
		
	}

}
