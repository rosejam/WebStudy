package com.basic;

public class Test1 {

	public static void main(String[] args) {
		int a = 9, b = 3, c = 5;
		System.out.println(++a + b++ + ++c);//
		System.out.println(a++ + ++b + ++c);

	}

}
