package com.prac.computer;

public class KeyBoard{
	String type;
	String maker;
	
	
	public KeyBoard(String type, String maker) {
		
		this.type = type;
		this.maker = maker;
	}


	public void keyType(){
		System.out.println("KeyBoard typing...");
	}
	
	
	public void info() {
		System.out.println("maker:" + maker);			
		System.out.println("type:" + type);
		
	}	
}
