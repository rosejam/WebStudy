package com.prac.computer;

public class Mouse{
	String maker;
	boolean wireless;			
	
	public Mouse(String maker, boolean wireless) {
		
		this.maker = maker;
		this.wireless = wireless;
	}

	void leftClick(){
		System.out.println("Mouse_LeftClick");
	}
	
	void rightClick(){
		System.out.println("Mouse_RightClick");
	}
	
	void wheeling(){
		System.out.println("Mouse_wheeling");
		
	}

	public void info() {		
		System.out.println("maker:" + maker);			
		System.out.println("wireless:" + wireless);			
	}
	
}







