package com.prac.computer;

public class MainFrame {
	String cpu;	
	String maker;
	
	public MainFrame(String cpu, String maker) {
		
		this.cpu = cpu;
		this.maker = maker;
	}

	public void powerOn(){
		System.out.println("MainFrame_PowerOn");		
	}
	
	public void powerOff(){
		System.out.println("MainFrame_PowerOff");		
	}

	
	public void info() {
		System.out.println("maker:" + maker);			
		System.out.println("cpu:" + cpu);
				
	}
	
}








