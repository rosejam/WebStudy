package com.prac.computer;

public class Monitor{

	double size;
	String maker;
	
	public Monitor(double size, String maker) {
		
		this.size = size;
		this.maker = maker;
	}
	public void powerOn(){
		System.out.println("Monitor_PowerOn");	
		
	}
	public void powerOff(){
		System.out.println("Monitor_PowerOff");	
		
	}

	
	public void info() {
		System.out.println("maker:" + maker);			
		System.out.println("size:" + size);
	}
	
}


